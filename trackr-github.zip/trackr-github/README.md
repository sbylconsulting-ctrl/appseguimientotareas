# Trackr

Aplicación estática para GitHub Pages conectada a Google Sheets mediante Apps Script.

## Archivos

- `index.html`: frontend de Trackr. Sube este archivo a la raíz del repositorio de GitHub.
- El backend debe ir en Google Apps Script como `Code.gs` y desplegarse como Aplicación web.

## Publicar en GitHub Pages

1. Crea un repositorio en GitHub, por ejemplo `trackr`.
2. Sube `index.html` a la raíz del repositorio.
3. Ve a **Settings → Pages**.
4. En **Build and deployment**, selecciona:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/root**
5. Guarda los cambios.
6. Abre la URL de GitHub Pages, normalmente:
   `https://TU-USUARIO.github.io/trackr/`

## Conectar con Google Sheets

1. En tu Google Sheet, abre **Extensiones → Apps Script**.
2. Pega el código backend en `Code.gs`.
3. Ve a **Implementar → Nueva implementación**.
4. Tipo: **Aplicación web**.
5. Ejecutar como: **Yo**.
6. Quién tiene acceso: **Cualquier usuario**.
7. Copia la URL que termina en `/exec`.
8. Abre Trackr en GitHub Pages y pega esa URL en la pantalla de conexión.
